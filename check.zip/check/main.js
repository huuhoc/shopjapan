function sliderAnimations() {
    $(".hero-slider .slide").each(function() {
        3 == $(this).css("z-index") && $(this).addClass("current"), 1 == $(this).css("z-index") && $(this).removeClass("current")
    })
}

function homeSlider() {
    heroLoader = new TimelineMax({
        paused: !0
    }), heroLoader.add(TweenMax.fromTo($(".load-circle"), 6, {
        drawSVG: "0%"
    }, {
        drawSVG: "100%"
    }));
    var imgLoad0 = imagesLoaded(".slider-holder", {
        background: !0
    }, function() {
        console.log("hero-slider loaded")
    });
    //console.log(imgLoad0)
    imgLoad0.on("done", function(instance) {
        homeSliderObj = new Core.Slider,
        window.setInterval(sliderAnimations, 50)
    })
}

function mobileToggle() {
    $(".mobile-toggle").on("click", function(e) {
        e.preventDefault(), $(this).toggleClass("open-nav"), $(".site-navigation").toggleClass("open-nav")
    }), $(window).width() < 720 && $(".site-navigation__item").on("click", function() {
        $(".site-navigation").removeClass("open-nav"), $(".mobile-toggle").removeClass("open-nav")
    })
}

function imageHover() {
    $(".featured-post .image, .featured-post h4").mouseover(function() {
        $(".featured-post").addClass("hover")
    }).mouseout(function() {
        $(".featured-post").removeClass("hover")
    }), $(".blog-posts__post .textured-image, .blog-posts__post h4").mouseover(function() {
        $(this).parent().parent().addClass("hover")
    }).mouseout(function() {
        $(this).parent().parent().removeClass("hover")
    })
}

function ourBrands() {
    $(".our-brands .col").mouseover(function() {
        TweenLite.to($(".our-brands .col"), .3, {
            opacity: "0.3"
        }), TweenLite.to($(this), .3, {
            opacity: "1"
        })
    }).mouseout(function() {
        TweenLite.to($(".our-brands .col"), .3, {
            opacity: "1"
        })
    })
}

function fixNav() {
    $(window).scroll(function() {
        $(window).scrollTop() >= 300 ? $("body").addClass("fixed-nav") : $("body").removeClass("fixed-nav")
    })
}

function inView() {
    $(".nudge, .slidein").on("inview", function(event, isInView) {
        isInView && $(this).addClass("inview")
    })
}

var heroLoader = "",
    homeSliderObj, Core;
! function(Core) {
    var Slider = function() {
        function Slider() {
            this.durations = {
                auto: 5400,
                slide: 1400
            }, this.dom = {
                wrapper: null,
                container: null,
                project: null,
                current: null,
                next: null,
                arrow: null
            }, this.length = 0, this.current = 0, this.next = 0, this.isAuto = !0, this.working = !1,
            this.dom.wrapper = $(".slider-holder"),
            this.dom.slide = this.dom.wrapper.find(".slide"),
            this.dom.arrow = this.dom.wrapper.find(".arrow"),
            this.length = this.dom.slide.length,
            this.init(),
            this.events(),
            this.auto = setInterval(this.updateNext.bind(this), this.durations.auto)
        }
        return Slider.prototype.init = function() {
            heroLoader.restart(), this.dom.slide.css("z-index", 1), this.dom.current = $(this.dom.slide[this.current]), this.dom.next = $(this.dom.slide[this.current + 1]), this.dom.current.css("z-index", 3), this.dom.next.css("z-index", 2)
        }, Slider.prototype.clear = function() {
            this.dom.arrow.off("click"), this.isAuto && clearInterval(this.auto)
        }, Slider.prototype.destroy = function() {
            this.dom.arrow.off("click"), clearInterval(this.auto)
        }, Slider.prototype.events = function() {
            var self = this;
            this.dom.arrow.on("click", function() {
                self.working || self.processBtn($(this))
            })
        }, Slider.prototype.processBtn = function(btn) {
            this.isAuto && (this.isAuto = !1, clearInterval(this.auto), heroLoader.restart(), heroLoader.pause()), btn.hasClass("next") && this.updateNext(), btn.hasClass("previous") && this.updatePrevious()
        }, Slider.prototype.updateNext = function() {
            this.next = (this.current + 1) % this.length, this.process()
        }, Slider.prototype.updatePrevious = function() {
            this.next--, this.next < 0 && (this.next = this.length - 1), this.process()
        }, Slider.prototype.process = function() {
            var self = this;
            this.working = !0, this.dom.next = $(this.dom.slide[this.next]), this.dom.current.css("z-index", 3), self.dom.next.css("z-index", 2), this.dom.current.addClass("hide"), setTimeout(function() {
                heroLoader.paused() || heroLoader.restart(), self.dom.current.css("z-index", 1), self.dom.next.css("z-index", 3), self.dom.current.removeClass("hide"), self.dom.current = self.dom.next, self.current = self.next, self.working = !1
            }, this.durations.slide)
        }, Slider
    }();
    Core.Slider = Slider
}(Core || (Core = {}));

var ajaxManager = function() {
    var requests = [];
    return {
        addReq: function(opt) {
            requests.push(opt)
        },
        removeReq: function(opt) {
            $.inArray(opt, requests) > -1 && requests.splice($.inArray(opt, requests), 1)
        },
        run: function() {
            var self = this,
                go = !0;
            if (Barba.Pjax.Cache.get(requests[0]) && (requests.shift(), go = !1), requests.length && go) {
                var xhr = Barba.Utils.xhr(requests[0]);
                xhr.then(function() {
                    Barba.Pjax.Cache.set(requests[0], xhr), requests.shift(), self.run.apply(self, [])
                })
            } else self.tid = setTimeout(function() {
                self.run.apply(self, [])
            }, 500)
        },
        stop: function() {
            requests = [], clearTimeout(this.tid)
        }
    }
}();
$(window).on("load", function() {
    setTimeout(function() {
        ajaxManager.run()
    }, 5e3)
})

var retailSlider = function() {
    var page = 1,
        maxPages = $(".retail-slider__logos").length,
        pagination = $(".retail-slider__pagination"),
        slideWidth = parseInt($(".retail-slider__holder").css("width")),
        _init = function() {
            $(".retail-slider__holder").hasClass("inited") || (page = 1, maxPages = $(".retail-slider__logos").length, pagination = $(".retail-slider__pagination"), slideWidth = parseInt($(".retail-slider__holder").css("width")), $(".retail-slider__logos").css("width", slideWidth), $(".retail-slider__button").on("click", function(e) {
                e.preventDefault(), _switchSlides($(this).hasClass("next") ? page + 1 : page - 1)
            }), _addPips(), _sortNavigation(), $(".retail-slider__holder").addClass("inited"))
        },
        _addPips = function() {
            for (var c = 1; c <= maxPages;) {
                var el = $("<li />", {
                    class: "retail-slider__pagination-item"
                }).on("click", function() {
                    _switchSlides($(this).index() + 1)
                });
                pagination.append(el), c++
            }
        },
        _switchSlides = function(target) {
            var targetWidth = slideWidth * (target - 1);
            $(".retail-slider__slide").css("margin-left", 0 - targetWidth), page = target, _sortNavigation()
        },
        _sortNavigation = function() {
            $(".retail-slider__button").css("visibility", "hidden"), page > 1 && $(".retail-slider__button.prev").css("visibility", "visible"), page != maxPages && $(".retail-slider__button.next").css("visibility", "visible"), $(".retail-slider__pagination li").removeClass("active"), $(".retail-slider__pagination li:eq(" + (page - 1) + ")").addClass("active")
        };
    return {
        init: function() {
            _init()
        }
    }
}();
retailSlider.init();

var Homepage = Barba.BaseView.extend({
    namespace: "homepage",
    onEnter: function() {},
    onEnterCompleted: function() {
        homeSlider()
    },
    onLeave: function() {},
    onLeaveCompleted: function() {
        heroLoader.clear(), homeSliderObj.destroy()
    }
});
Homepage.init();
var Page = Barba.BaseView.extend({
    namespace: "page",
    onEnter: function() {
        retailSlider.init()
    },
    onEnterCompleted: function() {},
    onLeave: function() {},
    onLeaveCompleted: function() {}
});
Page.init();

Barba.Pjax.start(), Barba.Utils.xhrTimeout = 15e3;

